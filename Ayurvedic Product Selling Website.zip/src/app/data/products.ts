export interface Product {
  id: number;
  name: string;
  nameMarathi: string;
  category: string;
  categoryMarathi: string;
  price: number;
  originalPrice?: number;
  image: string;
  shortDescription: string;
  shortDescriptionMarathi: string;
  description: string;
  descriptionMarathi: string;
  benefits: string[];
  benefitsMarathi: string[];
  ingredients: string[];
  ingredientsMarathi: string[];
  howToUse: string;
  howToUseMarathi: string;
  inStock: boolean;
  featured?: boolean;
  phoneNumber: string;
  whatsappNumber: string;
}

export const products: Product[] = [
  {
    id: 1,
    name: "Organic Turmeric Powder",
    nameMarathi: "शुद्ध हळद पावडर",
    category: "Herbs & Spices",
    categoryMarathi: "औषधी वनस्पती",
    price: 299,
    originalPrice: 399,
    image: "https://images.unsplash.com/photo-1768729340925-2749ecdc211c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxheXVydmVkaWMlMjBoZXJicyUyMHR1cm1lcmljfGVufDF8fHx8MTc3NTIwMTI1MHww&ixlib=rb-4.1.0&q=80&w=1080",
    shortDescription: "Pure, organic turmeric for daily wellness",
    shortDescriptionMarathi: "दररोजच्या आरोग्यासाठी शुद्ध आणि नैसर्गिक हळद",
    description: "100% Pure and Organic Turmeric Powder sourced from certified organic farms. Rich in curcumin, this golden spice is a powerhouse of antioxidants and anti-inflammatory properties. Traditional Ayurvedic medicine for overall wellness.",
    descriptionMarathi: "100% शुद्ध आणि ऑर्गॅनिक हळद पावडर, प्रमाणित शेतातून मिळवलेली. करक्यूमिनने भरपूर, हा सोनेरी मसाला अँटीऑक्सिडंट्स आणि दाहकविरोधी गुणधर्मांनी युक्त आहे. संपूर्ण आरोग्यासाठी पारंपरिक आयुर्वेदिक औषध.",
    benefits: [
      "Powerful anti-inflammatory properties",
      "Rich in antioxidants",
      "Supports joint health",
      "Boosts immunity naturally",
      "Promotes healthy digestion"
    ],
    benefitsMarathi: [
      "शक्तिशाली दाहकविरोधी गुणधर्म",
      "अँटीऑक्सिडंट्सने समृद्ध",
      "सांध्यांच्या आरोग्यास समर्थन",
      "नैसर्गिकरित्या रोगप्रतिकारक शक्ती वाढवते",
      "पचनक्रिया सुधारते"
    ],
    ingredients: ["100% Organic Turmeric (Curcuma longa)"],
    ingredientsMarathi: ["100% ऑर्गॅनिक हळद (करक्यूमा लोंगा)"],
    howToUse: "Mix 1/2 teaspoon with warm milk or water daily. Can also be added to cooking. Best consumed with a pinch of black pepper for enhanced absorption.",
    howToUseMarathi: "दररोज अर्धा चमचा कोमट दुधात किंवा पाण्यात मिसळा. स्वयंपाकात देखील वापरता येते. चांगल्या शोषणासाठी काळ्या मिरीसोबत घ्यावे.",
    inStock: true,
    featured: true,
    phoneNumber: "+919876543210",
    whatsappNumber: "919876543210"
  },
  {
    id: 2,
    name: "Ayurvedic Hair Oil",
    nameMarathi: "आयुर्वेदिक केशतेल",
    category: "Hair Care",
    categoryMarathi: "केस काळजी",
    price: 599,
    originalPrice: 799,
    image: "https://images.unsplash.com/photo-1590518563786-901882bf6f82?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxheXVydmVkaWMlMjBvaWwlMjBib3R0bGV8ZW58MXx8fHwxNzc1MjAxMjUwfDA&ixlib=rb-4.1.0&q=80&w=1080",
    shortDescription: "21 herbs blend for strong, healthy hair",
    shortDescriptionMarathi: "मजबूत आणि निरोगी केसांसाठी 21 औषधी वनस्पतींचे मिश्रण",
    description: "Traditional Ayurvedic hair oil made with 21 potent herbs infused in pure coconut and sesame oil. This ancient formula promotes hair growth, reduces hair fall, and nourishes the scalp naturally. No harmful chemicals, 100% natural ingredients.",
    descriptionMarathi: "शुद्ध नारळ आणि तीळ तेलात 21 शक्तिशाली औषधी वनस्पतींचे मिश्रण असलेले पारंपरिक आयुर्वेदिक केशतेल. ही प्राचीन फॉर्म्युला केसांची वाढ वाढवते, केस गळणे कमी करते आणि टाळूला नैसर्गिकरित्या पोषण देते. कोणतेही हानिकारक रसायन नाही, 100% नैसर्गिक घटक.",
    benefits: [
      "Reduces hair fall naturally",
      "Promotes healthy hair growth",
      "Nourishes scalp and roots",
      "Prevents premature greying",
      "Adds natural shine and strength"
    ],
    benefitsMarathi: [
      "केस गळणे नैसर्गिकरित्या कमी करते",
      "निरोगी केसांची वाढ वाढवते",
      "टाळू आणि मुळांना पोषण देते",
      "अकाली पांढरे होणे थांबवते",
      "नैसर्गिक चमक आणि मजबूती देते"
    ],
    ingredients: ["Coconut Oil", "Sesame Oil", "Bhringraj", "Amla", "Brahmi", "Neem", "Hibiscus", "Fenugreek"],
    ingredientsMarathi: ["नारळ तेल", "तीळ तेल", "भृंगराज", "आवळा", "ब्राह्मी", "कडुनिंब", "जास्वंद", "मेथी"],
    howToUse: "Warm the oil slightly and massage into scalp and hair. Leave for at least 1 hour or overnight for best results. Wash with a mild herbal shampoo.",
    howToUseMarathi: "तेल थोडे गरम करून टाळूवर आणि केसांवर मालिश करा. चांगल्या परिणामासाठी किमान 1 तास किंवा रात्रभर ठेवा. सौम्य हर्बल शॅम्पूने धुवा.",
    inStock: true,
    featured: true,
    phoneNumber: "+919876543210",
    whatsappNumber: "919876543210"
  },
  {
    id: 3,
    name: "Herbal Wellness Tea",
    nameMarathi: "हर्बल आरोग्य चहा",
    category: "Beverages",
    categoryMarathi: "पेय पदार्थ",
    price: 349,
    image: "https://images.unsplash.com/photo-1760074057726-e94ee8ff1eb4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZXJiYWwlMjB0ZWElMjBsZWF2ZXN8ZW58MXx8fHwxNzc1MjAxMjUyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    shortDescription: "Dosha balancing herbal tea blend",
    shortDescriptionMarathi: "दोष संतुलित करणारा हर्बल चहा",
    description: "Carefully crafted blend of authentic Ayurvedic herbs and premium tea leaves. This wellness tea helps balance all three doshas (Vata, Pitta, Kapha), improves digestion, and promotes overall wellbeing. Completely natural and caffeine-free option available.",
    descriptionMarathi: "अस्सल आयुर्वेदिक औषधी वनस्पती आणि प्रीमियम चहाच्या पानांचे काळजीपूर्वक तयार केलेले मिश्रण. हा आरोग्य चहा तीनही दोष (वात, पित्त, कफ) संतुलित करण्यास मदत करतो, पचनक्रिया सुधारतो आणि एकूण आरोग्य वाढवतो. पूर्णपणे नैसर्गिक आणि कॅफीनमुक्त पर्याय उपलब्ध.",
    benefits: [
      "Balances all three doshas",
      "Improves digestion",
      "Boosts metabolism",
      "Calms the mind",
      "Rich in antioxidants"
    ],
    benefitsMarathi: [
      "तीनही दोष संतुलित करते",
      "पचनक्रिया सुधारते",
      "चयापचय वाढवते",
      "मन शांत करते",
      "अँटीऑक्सिडंट्सने समृद्ध"
    ],
    ingredients: ["Green Tea", "Tulsi", "Ginger", "Cardamom", "Cinnamon", "Licorice", "Fennel"],
    ingredientsMarathi: ["ग्रीन टी", "तुळशी", "आले", "वेलची", "दालचिनी", "जेष्ठमध", "बडीशेप"],
    howToUse: "Steep one teaspoon in hot water for 3-5 minutes. Enjoy without milk for best results. Can be consumed 2-3 times daily.",
    howToUseMarathi: "एक चमचा गरम पाण्यात 3-5 मिनिटे भिजवा. चांगल्या परिणामासाठी दूध न घालता आस्वाद घ्या. दिवसातून 2-3 वेळा घेता येते.",
    inStock: true,
    featured: false,
    phoneNumber: "+919876543210",
    whatsappNumber: "919876543210"
  },
  {
    id: 4,
    name: "Ashwagandha Root Powder",
    nameMarathi: "अश्वगंधा मूळ पावडर",
    category: "Herbs & Supplements",
    categoryMarathi: "औषधी वनस्पती",
    price: 449,
    originalPrice: 599,
    image: "https://images.unsplash.com/photo-1704650312022-ed1a76dbed1b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc2h3YWdhbmRoYSUyMHBvd2RlcnxlbnwxfHx8fDE3NzUyMDEyNTN8MA&ixlib=rb-4.1.0&q=80&w=1080",
    shortDescription: "Ancient adaptogen for stress and strength",
    shortDescriptionMarathi: "तणाव आणि शक्तीसाठी प्राचीन औषध",
    description: "Premium quality Ashwagandha root powder, known as the 'King of Ayurveda'. This ancient adaptogen is clinically proven to reduce stress, improve strength, and enhance vitality. Safe for long-term use with no side effects.",
    descriptionMarathi: "'आयुर्वेदाचा राजा' म्हणून ओळखली जाणारी प्रीमियम दर्जाची अश्वगंधा मूळ पावडर. हे प्राचीन औषध तणाव कमी करते, शक्ती सुधारते आणि चैतन्य वाढवते असे वैद्यकीयदृष्ट्या सिद्ध झाले आहे. दीर्घकालीन वापरासाठी सुरक्षित, कोणतेही दुष्परिणाम नाहीत.",
    benefits: [
      "Reduces stress and anxiety naturally",
      "Improves strength and stamina",
      "Enhances mental clarity and focus",
      "Supports healthy sleep patterns",
      "Balances hormones naturally"
    ],
    benefitsMarathi: [
      "तणाव आणि चिंता नैसर्गिकरित्या कमी करते",
      "शक्ती आणि तग धरण्याची क्षमता वाढवते",
      "मानसिक स्पष्टता आणि एकाग्रता वाढवते",
      "निरोगी झोपेच्या पद्धतींना समर्थन देते",
      "हार्मोन्स नैसर्गिकरित्या संतुलित करते"
    ],
    ingredients: ["100% Pure Ashwagandha Root Powder (Withania somnifera)"],
    ingredientsMarathi: ["100% शुद्ध अश्वगंधा मूळ पावडर (विथानिया सोम्निफेरा)"],
    howToUse: "Mix 1/4 to 1/2 teaspoon with warm milk or water before bedtime. Can also be taken in the morning. Consult an Ayurvedic practitioner for personalized dosage.",
    howToUseMarathi: "झोपण्यापूर्वी 1/4 ते 1/2 चमचा कोमट दुधात किंवा पाण्यात मिसळा. सकाळी देखील घेता येते. वैयक्तिक डोससाठी आयुर्वेदिक वैद्यांचा सल्ला घ्या.",
    inStock: true,
    featured: true,
    phoneNumber: "+919876543210",
    whatsappNumber: "919876543210"
  },
  {
    id: 5,
    name: "Moringa Leaf Powder",
    nameMarathi: "शेवगा पानांची पावडर",
    category: "Superfoods",
    categoryMarathi: "सुपरफूड",
    price: 399,
    image: "https://images.unsplash.com/photo-1771643033515-0028fd03b708?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3JpbmdhJTIwbGVhdmVzJTIwbmF0dXJhbHxlbnwxfHx8fDE3NzUyMDEyNTN8MA&ixlib=rb-4.1.0&q=80&w=1080",
    shortDescription: "Nutrient-rich superfood for complete nutrition",
    shortDescriptionMarathi: "संपूर्ण पोषणासाठी पोषक तत्त्वांनी भरपूर सुपरफूड",
    description: "Pure Moringa leaf powder, known as the 'Miracle Tree' in Ayurveda. Packed with 90+ nutrients including vitamins, minerals, and complete protein. Ideal for overall health, energy, and immunity boost.",
    descriptionMarathi: "आयुर्वेदात 'चमत्कारिक वृक्ष' म्हणून ओळखली जाणारी शुद्ध शेवगा पानांची पावडर. जीवनसत्त्वे, खनिजे आणि संपूर्ण प्रथिनांसह 90+ पोषक तत्त्वांनी भरलेली. एकूण आरोग्य, ऊर्जा आणि रोगप्रतिकारक शक्ती वाढवण्यासाठी आदर्श.",
    benefits: [
      "Rich in vitamins A, C, and E",
      "High protein content (25%)",
      "Boosts energy levels naturally",
      "Supports immune system",
      "Promotes healthy skin and hair"
    ],
    benefitsMarathi: [
      "व्हिटॅमिन A, C आणि E ने समृद्ध",
      "उच्च प्रथिन सामग्री (25%)",
      "ऊर्जा पातळी नैसर्गिकरित्या वाढवते",
      "रोगप्रतिकारक शक्तीला समर्थन देते",
      "निरोगी त्वचा आणि केसांना प्रोत्साहन देते"
    ],
    ingredients: ["100% Organic Moringa Leaf Powder (Moringa oleifera)"],
    ingredientsMarathi: ["100% ऑर्गॅनिक शेवगा पानांची पावडर (मोरिंगा ओलीफेरा)"],
    howToUse: "Add 1 teaspoon to smoothies, juices, or warm water. Can also be mixed with yogurt or sprinkled on salads. Best consumed in the morning on empty stomach.",
    howToUseMarathi: "स्मूदी, ज्यूस किंवा कोमट पाण्यात 1 चमचा घाला. दह्यात मिसळून किंवा सॅलडवर शिंपडून देखील वापरता येते. रिकाम्या पोटी सकाळी घेणे चांगले.",
    inStock: true,
    featured: false,
    phoneNumber: "+919876543210",
    whatsappNumber: "919876543210"
  },
  {
    id: 6,
    name: "Ayurvedic Face Cream",
    nameMarathi: "आयुर्वेदिक चेहरा क्रीम",
    category: "Skincare",
    categoryMarathi: "त्वचा काळजी",
    price: 699,
    originalPrice: 899,
    image: "https://images.unsplash.com/photo-1737100763256-378f09fda936?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxheXVydmVkaWMlMjBza2luY2FyZSUyMGNyZWFtfGVufDF8fHx8MTc3NTIwMTI1NHww&ixlib=rb-4.1.0&q=80&w=1080",
    shortDescription: "Natural glow and anti-aging face cream",
    shortDescriptionMarathi: "नैसर्गिक चमक आणि वयप्रतिबंधक चेहरा क्रीम",
    description: "Luxurious Ayurvedic face cream formulated with rare herbs and natural ingredients. This premium cream deeply nourishes, hydrates, and rejuvenates all skin types naturally. Suitable for sensitive skin, dermatologically tested.",
    descriptionMarathi: "दुर्मिळ औषधी वनस्पती आणि नैसर्गिक घटकांसह तयार केलेली आलिशान आयुर्वेदिक चेहरा क्रीम. ही प्रीमियम क्रीम सर्व प्रकारच्या त्वचेला खोलवर पोषण देते, मॉइश्चरायझ करते आणि तारुण्य देते. संवेदनशील त्वचेसाठी योग्य, त्वचाशास्त्रीय चाचणी घेतलेली.",
    benefits: [
      "Deep hydration and nourishment",
      "Reduces fine lines and wrinkles",
      "Improves skin texture and tone",
      "Natural glow enhancement",
      "Suitable for all skin types"
    ],
    benefitsMarathi: [
      "खोल आर्द्रता आणि पोषण",
      "सूक्ष्म रेषा आणि सुरकुत्या कमी करते",
      "त्वचेची रचना आणि रंग सुधारते",
      "नैसर्गिक चमक वाढवते",
      "सर्व प्रकारच्या त्वचेसाठी योग्य"
    ],
    ingredients: ["Saffron", "Almond Oil", "Sandalwood", "Turmeric", "Rose Water", "Aloe Vera", "Shea Butter"],
    ingredientsMarathi: ["केशर", "बदाम तेल", "चंदन", "हळद", "गुलाबजल", "कोरफड", "शिया बटर"],
    howToUse: "Cleanse face thoroughly. Apply a small amount to face and neck using gentle upward motions. Use morning and night for best results. No side effects.",
    howToUseMarathi: "चेहरा चांगल्या प्रकारे स्वच्छ करा. हलक्या हाताने वरच्या दिशेने चेहरा आणि मानेवर थोडे प्रमाण लावा. चांगल्या परिणामासाठी सकाळ आणि रात्री वापरा. कोणतेही दुष्परिणाम नाहीत.",
    inStock: true,
    featured: false,
    phoneNumber: "+919876543210",
    whatsappNumber: "919876543210"
  }
];

export const contactInfo = {
  phone: "+91 98765 43210",
  whatsapp: "919876543210",
  email: "info@ayurvedafoundation.org",
  address: "123, Ayurveda Bhavan, Pune, Maharashtra 411001",
  addressMarathi: "१२३, आयुर्वेद भवन, पुणे, महाराष्ट्र ४११००१"
};

export const foundationInfo = {
  name: "Ayurveda Health Foundation",
  nameMarathi: "आयुर्वेद आरोग्य प्रतिष्ठान",
  tagline: "Nature's Wisdom for Modern Wellness",
  taglineMarathi: "आधुनिक आरोग्यासाठी निसर्गाचे ज्ञान",
  description: "We are a registered social foundation dedicated to promoting authentic Ayurvedic wellness. Our products are crafted using traditional formulations and 100% natural ingredients. Every purchase supports our mission to provide affordable healthcare to underprivileged communities.",
  descriptionMarathi: "आम्ही अस्सल आयुर्वेदिक आरोग्य प्रोत्साहन देण्यासाठी समर्पित एक नोंदणीकृत सामाजिक प्रतिष्ठान आहोत. आमची उत्पादने पारंपरिक सूत्रांचा आणि 100% नैसर्गिक घटकांचा वापर करून तयार केली जातात. प्रत्येक खरेदी वंचित समुदायांना परवडणारी आरोग्य सेवा प्रदान करण्याच्या आमच्या ध्येयाला समर्थन देते."
};
