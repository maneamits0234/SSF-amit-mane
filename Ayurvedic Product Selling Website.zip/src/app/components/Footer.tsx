import { Phone, Mail, MapPin, Leaf, MessageCircle } from "lucide-react";
import { contactInfo, foundationInfo } from "../data/products";

export function Footer() {
  const currentYear = new Date().getFullYear();

  const handleWhatsApp = () => {
    window.open(`https://wa.me/${contactInfo.whatsapp}?text=नमस्कार, मला आयुर्वेदिक उत्पादनांबद्दल माहिती हवी आहे.`, '_blank');
  };

  return (
    <footer className="bg-gradient-to-b from-gray-900 to-gray-950 text-white">
      <div className="container mx-auto px-4 py-12 md:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-10">
          {/* About Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-[#2d7a3e] rounded-full flex items-center justify-center">
                <Leaf className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">AyurVeda</h3>
                <p className="text-xs text-gray-400">Health Foundation</p>
              </div>
            </div>
            <p className="text-sm text-gray-300 leading-relaxed">
              {foundationInfo.descriptionMarathi.substring(0, 150)}...
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a href="/" className="text-gray-300 hover:text-[#2d7a3e] transition-colors">
                  Home | होम
                </a>
              </li>
              <li>
                <a 
                  href="#products" 
                  className="text-gray-300 hover:text-[#2d7a3e] transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  Products | उत्पादने
                </a>
              </li>
              <li>
                <a 
                  href="#about" 
                  className="text-gray-300 hover:text-[#2d7a3e] transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  About Us | आमच्याबद्दल
                </a>
              </li>
              <li>
                <a 
                  href="#contact" 
                  className="text-gray-300 hover:text-[#2d7a3e] transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  Contact | संपर्क
                </a>
              </li>
            </ul>
          </div>

          {/* Products Categories */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Categories | श्रेणी</h3>
            <ul className="space-y-3 text-sm">
              <li className="text-gray-300">
                औषधी वनस्पती | Herbs
              </li>
              <li className="text-gray-300">
                केस काळजी | Hair Care
              </li>
              <li className="text-gray-300">
                त्वचा काळजी | Skincare
              </li>
              <li className="text-gray-300">
                सुपरफूड | Superfoods
              </li>
              <li className="text-gray-300">
                पेय पदार्थ | Beverages
              </li>
            </ul>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact | संपर्क</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <a 
                  href={`tel:${contactInfo.phone}`}
                  className="flex items-start gap-2 text-gray-300 hover:text-[#2d7a3e] transition-colors"
                >
                  <Phone className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span>{contactInfo.phone}</span>
                </a>
              </li>
              <li>
                <button
                  onClick={handleWhatsApp}
                  className="flex items-start gap-2 text-gray-300 hover:text-[#2d7a3e] transition-colors text-left"
                >
                  <MessageCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span>WhatsApp Enquiry</span>
                </button>
              </li>
              <li>
                <a 
                  href={`mailto:${contactInfo.email}`}
                  className="flex items-start gap-2 text-gray-300 hover:text-[#2d7a3e] transition-colors"
                >
                  <Mail className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span className="break-all">{contactInfo.email}</span>
                </a>
              </li>
              <li>
                <div className="flex items-start gap-2 text-gray-300">
                  <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span>{contactInfo.addressMarathi}</span>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-10 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-gray-400">
            <p>
              &copy; {currentYear} {foundationInfo.nameMarathi}. सर्व हक्क राखीव.
            </p>
            <p className="text-center md:text-right">
              100% नैसर्गिक | कोणतेही साइड इफेक्ट नाहीत | विश्वासार्ह उत्पादने
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
