import { ShoppingCart, Menu, X, Leaf, Phone } from "lucide-react";
import { Link } from "react-router";
import { useState } from "react";
import { contactInfo } from "../data/products";

interface HeaderProps {
  cartItemCount: number;
  onCartClick: () => void;
}

export function Header({ cartItemCount, onCartClick }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleCallNow = () => {
    window.location.href = `tel:${contactInfo.phone}`;
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md border-b border-[#2d7a3e]/10">
      {/* Top Bar - Contact Info */}
      <div className="bg-[#2d7a3e] text-white py-2">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between text-xs md:text-sm">
            <div className="flex items-center gap-1">
              <Phone className="w-3 h-3 md:w-4 md:h-4" />
              <a href={`tel:${contactInfo.phone}`} className="hover:underline">
                {contactInfo.phone}
              </a>
            </div>
            <div className="hidden sm:block">
              <span className="opacity-90">100% नैसर्गिक आयुर्वेदिक उत्पादने | 100% Natural Ayurvedic Products</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 md:gap-3 hover:opacity-90 transition-opacity">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-[#2d7a3e] rounded-full flex items-center justify-center shadow-md">
              <Leaf className="w-6 h-6 md:w-7 md:h-7 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-base md:text-xl font-semibold text-[#2d7a3e] leading-tight">
                AyurVeda
              </span>
              <span className="text-[10px] md:text-xs text-[#8b7355] leading-tight">
                Health Foundation
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6 lg:gap-8">
            <Link 
              to="/" 
              className="text-gray-700 hover:text-[#2d7a3e] transition-colors font-medium"
            >
              Home
            </Link>
            <a 
              href="#products" 
              className="text-gray-700 hover:text-[#2d7a3e] transition-colors font-medium"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Products
            </a>
            <a 
              href="#about" 
              className="text-gray-700 hover:text-[#2d7a3e] transition-colors font-medium"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              About Us
            </a>
            <a 
              href="#contact" 
              className="text-gray-700 hover:text-[#2d7a3e] transition-colors font-medium"
              onClick={(e) => {
                e.preventDefault();
                document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
              }}
            >
              Contact
            </a>
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-2 md:gap-4">
            {/* Call Now Button - Desktop */}
            <button
              onClick={handleCallNow}
              className="hidden md:flex items-center gap-2 bg-[#2d7a3e] hover:bg-[#245c30] text-white px-4 py-2 rounded-lg transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span>Call Now</span>
            </button>

            {/* Cart Button */}
            <button
              onClick={onCartClick}
              className="relative p-2 hover:bg-gray-100 rounded-full transition-colors"
              aria-label="Shopping cart"
            >
              <ShoppingCart className="w-5 h-5 md:w-6 md:h-6 text-gray-700" />
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#d4183d] text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-medium">
                  {cartItemCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6 text-gray-700" />
              ) : (
                <Menu className="w-6 h-6 text-gray-700" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col gap-1">
              <Link
                to="/"
                className="text-gray-700 hover:text-[#2d7a3e] hover:bg-gray-50 transition-colors py-3 px-2 rounded"
                onClick={() => setMobileMenuOpen(false)}
              >
                Home
              </Link>
              <a
                href="#products"
                className="text-gray-700 hover:text-[#2d7a3e] hover:bg-gray-50 transition-colors py-3 px-2 rounded"
                onClick={(e) => {
                  e.preventDefault();
                  setMobileMenuOpen(false);
                  document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Products
              </a>
              <a
                href="#about"
                className="text-gray-700 hover:text-[#2d7a3e] hover:bg-gray-50 transition-colors py-3 px-2 rounded"
                onClick={(e) => {
                  e.preventDefault();
                  setMobileMenuOpen(false);
                  document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                About Us
              </a>
              <a
                href="#contact"
                className="text-gray-700 hover:text-[#2d7a3e] hover:bg-gray-50 transition-colors py-3 px-2 rounded"
                onClick={(e) => {
                  e.preventDefault();
                  setMobileMenuOpen(false);
                  document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Contact
              </a>
              <button
                onClick={() => {
                  handleCallNow();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center justify-center gap-2 bg-[#2d7a3e] hover:bg-[#245c30] text-white py-3 px-4 rounded-lg transition-colors mt-2"
              >
                <Phone className="w-4 h-4" />
                <span>Call Now</span>
              </button>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
