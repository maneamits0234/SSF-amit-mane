import { X, Plus, Minus, Trash2, ShoppingBag, Phone, MessageCircle } from "lucide-react";
import { Product } from "../data/products";
import { contactInfo } from "../data/products";

export interface CartItem extends Product {
  quantity: number;
}

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: number, quantity: number) => void;
  onRemoveItem: (productId: number) => void;
}

export function Cart({ isOpen, onClose, items, onUpdateQuantity, onRemoveItem }: CartProps) {
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = subtotal > 500 ? 0 : 50;
  const total = subtotal + shipping;

  const handleCallNow = () => {
    window.location.href = `tel:${contactInfo.phone}`;
  };

  const handleWhatsApp = () => {
    const message = `नमस्कार, मला खालील उत्पादनांची ऑर्डर करायची आहे:\n\n${items.map(item => `${item.nameMarathi} x ${item.quantity} = ₹${item.price * item.quantity}`).join('\n')}\n\nएकूण: ₹${total}`;
    window.open(`https://wa.me/${contactInfo.whatsapp}?text=${encodeURIComponent(message)}`, '_blank');
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black bg-opacity-50 z-50 transition-opacity"
        onClick={onClose}
      />

      {/* Cart Panel */}
      <div className="fixed right-0 top-0 h-full w-full sm:w-[420px] bg-white z-50 shadow-2xl flex flex-col animate-in slide-in-from-right">
        {/* Header */}
        <div className="flex items-center justify-between p-4 md:p-5 border-b bg-gradient-to-r from-[#2d7a3e] to-[#245c30] text-white">
          <div>
            <h2 className="text-lg md:text-xl font-bold">तुमची कार्ट</h2>
            <p className="text-xs md:text-sm opacity-90">
              {items.length} उत्पादने
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-full transition-colors"
            aria-label="Close cart"
          >
            <X className="w-5 h-5 md:w-6 md:h-6" />
          </button>
        </div>

        {/* Cart Items */}
        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <ShoppingBag className="w-20 h-20 text-gray-300 mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">कार्ट रिकामी आहे</h3>
            <p className="text-sm text-gray-500 mb-6">
              तुमची आवडती आयुर्वेदिक उत्पादने जोडा!
            </p>
            <button
              onClick={onClose}
              className="bg-[#2d7a3e] hover:bg-[#245c30] text-white px-6 py-3 rounded-lg transition-colors"
            >
              खरेदी सुरू करा
            </button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto p-4">
              <div className="space-y-4">
                {items.map((item) => (
                  <div key={item.id} className="flex gap-4 bg-gray-50 p-3 md:p-4 rounded-xl border border-gray-100">
                    <img
                      src={item.image}
                      alt={item.nameMarathi}
                      className="w-20 h-20 md:w-24 md:h-24 object-cover rounded-lg"
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm md:text-base font-semibold text-gray-900 mb-1 line-clamp-2">
                        {item.nameMarathi}
                      </h3>
                      <p className="text-[#2d7a3e] font-bold mb-3">₹{item.price}</p>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                          className="w-8 h-8 flex items-center justify-center bg-white border-2 border-gray-300 rounded-lg hover:border-[#2d7a3e] hover:bg-gray-50 transition-colors"
                          aria-label="Decrease quantity"
                        >
                          <Minus className="w-4 h-4 text-gray-700" />
                        </button>
                        <span className="text-sm font-semibold text-gray-700 w-10 text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                          className="w-8 h-8 flex items-center justify-center bg-white border-2 border-gray-300 rounded-lg hover:border-[#2d7a3e] hover:bg-gray-50 transition-colors"
                          aria-label="Increase quantity"
                        >
                          <Plus className="w-4 h-4 text-gray-700" />
                        </button>
                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="ml-auto p-2 hover:bg-red-50 rounded-full transition-colors"
                          aria-label="Remove item"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="border-t bg-gray-50 p-4 md:p-5 space-y-4">
              {/* Summary */}
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-gray-700">
                  <span>उप-एकूण</span>
                  <span className="font-semibold">₹{subtotal}</span>
                </div>
                <div className="flex justify-between text-gray-700">
                  <span>वितरण शुल्क</span>
                  <span className="font-semibold">
                    {shipping === 0 ? (
                      <span className="text-[#2d7a3e]">मोफत</span>
                    ) : (
                      `₹${shipping}`
                    )}
                  </span>
                </div>
                {shipping === 0 && (
                  <p className="text-xs text-[#2d7a3e] bg-[#e8f5e9] p-2 rounded">
                    🎉 तुम्हाला मोफत वितरण मिळाले!
                  </p>
                )}
                {shipping > 0 && (
                  <p className="text-xs text-gray-600 bg-gray-100 p-2 rounded">
                    मोफत वितरणासाठी आणखी ₹{500 - subtotal} चे खरेदी करा
                  </p>
                )}
                <div className="flex justify-between pt-3 border-t-2 text-base md:text-lg font-bold text-gray-900">
                  <span>एकूण</span>
                  <span className="text-[#2d7a3e]">₹{total}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                <button
                  onClick={handleCallNow}
                  className="w-full bg-[#2d7a3e] hover:bg-[#245c30] text-white py-3 rounded-xl transition-colors flex items-center justify-center gap-2 font-semibold shadow-lg"
                >
                  <Phone className="w-5 h-5" />
                  <span>कॉल करून ऑर्डर करा</span>
                </button>
                
                <button
                  onClick={handleWhatsApp}
                  className="w-full bg-[#25D366] hover:bg-[#20BA5A] text-white py-3 rounded-xl transition-colors flex items-center justify-center gap-2 font-semibold shadow-lg"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>WhatsApp वर ऑर्डर करा</span>
                </button>
              </div>

              <p className="text-xs text-center text-gray-500">
                सुरक्षित आणि विश्वासार्ह व्यवहार
              </p>
            </div>
          </>
        )}
      </div>
    </>
  );
}
