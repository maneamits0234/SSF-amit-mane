import { Star, ArrowRight } from "lucide-react";
import { Link } from "react-router";
import { Product } from "../data/products";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <Link
      to={`/product/${product.id}`}
      className="group bg-white rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100 hover:border-[#2d7a3e]/20 flex flex-col"
    >
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-gray-50 to-gray-100">
        <img
          src={product.image}
          alt={product.nameMarathi}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          loading="lazy"
        />
        {discount > 0 && (
          <div className="absolute top-3 right-3 bg-[#d4183d] text-white px-3 py-1.5 rounded-full flex items-center gap-1 text-xs font-semibold shadow-lg">
            <span>{discount}% छूट</span>
          </div>
        )}
        {product.featured && (
          <div className="absolute top-3 left-3 bg-[#2d7a3e] text-white px-3 py-1.5 rounded-full text-xs font-semibold shadow-lg">
            विशेष
          </div>
        )}
        {!product.inStock && (
          <div className="absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center">
            <span className="bg-white px-6 py-3 rounded-lg font-semibold text-gray-900">
              स्टॉक संपला
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4 md:p-5 flex flex-col flex-grow">
        <p className="text-xs text-[#8b7355] mb-1.5 font-medium">
          {product.categoryMarathi}
        </p>
        
        {/* Product Name - Marathi Primary */}
        <h3 className="text-base md:text-lg mb-1.5 text-gray-900 font-semibold line-clamp-2 group-hover:text-[#2d7a3e] transition-colors min-h-[3rem]">
          {product.nameMarathi}
        </h3>
        
        {/* English Name - Secondary */}
        <p className="text-xs text-gray-500 mb-3 line-clamp-1">
          {product.name}
        </p>

        {/* Short Description */}
        <p className="text-sm text-gray-600 mb-4 line-clamp-2 flex-grow">
          {product.shortDescriptionMarathi}
        </p>

        {/* Price and CTA */}
        <div className="flex items-center justify-between mt-auto pt-3 border-t border-gray-100">
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-xl md:text-2xl font-bold text-[#2d7a3e]">
                ₹{product.price}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-gray-400 line-through">
                  ₹{product.originalPrice}
                </span>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-1 text-[#2d7a3e] font-medium text-sm group-hover:gap-2 transition-all">
            <span>तपशील</span>
            <ArrowRight className="w-4 h-4" />
          </div>
        </div>
      </div>
    </Link>
  );
}
