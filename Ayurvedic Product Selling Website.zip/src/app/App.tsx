import { useState, useEffect } from "react";
import { RouterProvider } from "react-router";
import { createRouter } from "./routes";
import { products } from "./data/products";
import { CartItem } from "./components/Cart";

export default function App() {
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleAddToCart = (productId: number) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    setCartItems((prev) => {
      const existingItem = prev.find((item) => item.id === productId);
      if (existingItem) {
        return prev.map((item) =>
          item.id === productId ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });

    // Show cart briefly when item is added
    setCartOpen(true);
    setTimeout(() => setCartOpen(false), 2000);
  };

  const handleUpdateQuantity = (productId: number, quantity: number) => {
    setCartItems((prev) =>
      prev.map((item) => (item.id === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveItem = (productId: number) => {
    setCartItems((prev) => prev.filter((item) => item.id !== productId));
  };

  const router = createRouter({ 
    onAddToCart: handleAddToCart,
    cartOpen,
    setCartOpen,
    cartItems,
    onUpdateQuantity: handleUpdateQuantity,
    onRemoveItem: handleRemoveItem,
  });

  return <RouterProvider router={router} />;
}