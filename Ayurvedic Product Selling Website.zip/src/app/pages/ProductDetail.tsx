import { useParams, Link } from "react-router";
import { Star, ShoppingCart, Check, ArrowLeft, Package, Leaf, Shield, Phone, MessageCircle, Heart } from "lucide-react";
import { products } from "../data/products";
import { Footer } from "../components/Footer";
import { useState, useEffect } from "react";

interface ProductDetailProps {
  onAddToCart: (productId: number) => void;
}

export function ProductDetail({ onAddToCart }: ProductDetailProps) {
  const { id } = useParams();
  const product = products.find((p) => p.id === Number(id));
  const [showStickyBar, setShowStickyBar] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowStickyBar(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl text-gray-900 mb-4">उत्पादन सापडले नाही</h1>
        <Link to="/" className="text-[#2d7a3e] hover:underline">
          मुख्यपृष्ठावर परत या
        </Link>
      </div>
    );
  }

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleCallNow = () => {
    window.location.href = `tel:${product.phoneNumber}`;
  };

  const handleWhatsApp = () => {
    const message = `नमस्कार, मला ${product.nameMarathi} बद्दल माहिती हवी आहे.`;
    window.open(`https://wa.me/${product.whatsappNumber}?text=${encodeURIComponent(message)}`, '_blank');
  };

  const relatedProducts = products.filter(
    (p) => p.id !== product.id && p.category === product.category
  ).slice(0, 3);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Back Button */}
      <div className="bg-white border-b sticky top-[73px] md:top-[81px] z-40">
        <div className="container mx-auto px-4 py-3 md:py-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-gray-600 hover:text-[#2d7a3e] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm md:text-base">सर्व उत्पादनांकडे परत</span>
          </Link>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 md:py-10">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
            {/* Product Image */}
            <div className="relative bg-gradient-to-br from-gray-50 to-gray-100">
              <img
                src={product.image}
                alt={product.nameMarathi}
                className="w-full h-[350px] sm:h-[450px] lg:h-[600px] object-cover"
              />
              {discount > 0 && (
                <div className="absolute top-6 right-6 bg-[#d4183d] text-white px-4 py-2 rounded-full text-sm md:text-base font-bold shadow-lg">
                  {discount}% छूट
                </div>
              )}
              {product.featured && (
                <div className="absolute top-6 left-6 bg-[#2d7a3e] text-white px-4 py-2 rounded-full text-sm md:text-base font-bold shadow-lg">
                  विशेष उत्पादन
                </div>
              )}
            </div>

            {/* Product Info */}
            <div className="p-6 md:p-8 lg:p-10">
              <p className="text-sm text-[#8b7355] mb-2 font-medium">
                {product.categoryMarathi}
              </p>
              
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-2">
                {product.nameMarathi}
              </h1>
              
              <p className="text-base md:text-lg text-gray-600 mb-4">
                {product.name}
              </p>

              {/* Price */}
              <div className="flex items-center gap-3 mb-6 pb-6 border-b">
                <span className="text-3xl md:text-4xl font-bold text-[#2d7a3e]">
                  ₹{product.price}
                </span>
                {product.originalPrice && (
                  <>
                    <span className="text-lg md:text-xl text-gray-400 line-through">
                      ₹{product.originalPrice}
                    </span>
                    <span className="bg-[#d4183d] text-white px-3 py-1 rounded-full text-sm font-semibold">
                      {discount}% वाचवा
                    </span>
                  </>
                )}
              </div>

              {/* Short Description */}
              <p className="text-base md:text-lg text-gray-700 mb-6 leading-relaxed">
                {product.shortDescriptionMarathi}
              </p>

              {/* CTA Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
                <button
                  onClick={handleCallNow}
                  className="group bg-[#2d7a3e] hover:bg-[#245c30] text-white py-3 md:py-4 rounded-xl transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 font-semibold"
                >
                  <Phone className="w-5 h-5 group-hover:animate-pulse" />
                  <span>आता कॉल करा</span>
                </button>
                
                <button
                  onClick={handleWhatsApp}
                  className="group bg-[#25D366] hover:bg-[#20BA5A] text-white py-3 md:py-4 rounded-xl transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 font-semibold"
                >
                  <MessageCircle className="w-5 h-5 group-hover:animate-pulse" />
                  <span>WhatsApp करा</span>
                </button>
              </div>

              <button
                onClick={() => onAddToCart(product.id)}
                disabled={!product.inStock}
                className="w-full bg-gray-900 hover:bg-gray-800 disabled:bg-gray-400 disabled:cursor-not-allowed text-white py-3 md:py-4 rounded-xl transition-colors flex items-center justify-center gap-2 font-semibold mb-6"
              >
                <ShoppingCart className="w-5 h-5" />
                {product.inStock ? "कार्टमध्ये जोडा" : "स्टॉक संपला"}
              </button>

              {/* Trust Badges */}
              <div className="grid grid-cols-3 gap-3 md:gap-4 pb-6 border-b">
                <div className="text-center">
                  <div className="w-12 h-12 bg-[#e8f5e9] rounded-full flex items-center justify-center mx-auto mb-2">
                    <Package className="w-6 h-6 text-[#2d7a3e]" />
                  </div>
                  <p className="text-xs md:text-sm text-gray-600 font-medium">मोफत वितरण</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-[#e8f5e9] rounded-full flex items-center justify-center mx-auto mb-2">
                    <Leaf className="w-6 h-6 text-[#2d7a3e]" />
                  </div>
                  <p className="text-xs md:text-sm text-gray-600 font-medium">100% नैसर्गिक</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-[#e8f5e9] rounded-full flex items-center justify-center mx-auto mb-2">
                    <Shield className="w-6 h-6 text-[#2d7a3e]" />
                  </div>
                  <p className="text-xs md:text-sm text-gray-600 font-medium">गुणवत्ता चाचणी</p>
                </div>
              </div>

              {/* Benefits */}
              <div className="pt-6">
                <h2 className="text-lg md:text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Heart className="w-5 h-5 text-[#d4183d]" />
                  मुख्य फायदे
                </h2>
                <ul className="space-y-3">
                  {product.benefitsMarathi.map((benefit, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-[#2d7a3e] flex-shrink-0 mt-0.5" />
                      <span className="text-sm md:text-base text-gray-700">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Additional Info - Full Width */}
          <div className="bg-gradient-to-b from-gray-50 to-white p-6 md:p-10 border-t">
            <div className="max-w-5xl mx-auto">
              {/* Description */}
              <div className="mb-8 md:mb-10">
                <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-4">
                  तपशीलवार माहिती
                </h2>
                <p className="text-base md:text-lg text-gray-700 leading-relaxed">
                  {product.descriptionMarathi}
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6 md:gap-8">
                {/* Ingredients */}
                <div className="bg-white p-6 rounded-xl shadow-sm">
                  <h2 className="text-lg md:text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Leaf className="w-5 h-5 text-[#2d7a3e]" />
                    घटक (Ingredients)
                  </h2>
                  <ul className="space-y-2">
                    {product.ingredientsMarathi.map((ingredient, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <span className="text-[#2d7a3e] mt-1">•</span>
                        <span className="text-sm md:text-base text-gray-700">{ingredient}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* How to Use */}
                <div className="bg-white p-6 rounded-xl shadow-sm">
                  <h2 className="text-lg md:text-xl font-bold text-gray-900 mb-4">
                    वापरण्याची पद्धत
                  </h2>
                  <p className="text-sm md:text-base text-gray-700 leading-relaxed">
                    {product.howToUseMarathi}
                  </p>
                  
                  <div className="mt-4 p-4 bg-[#e8f5e9] rounded-lg">
                    <p className="text-sm text-gray-700">
                      <strong>टीप:</strong> चांगल्या परिणामांसाठी नियमितपणे वापरा. कोणत्याही प्रश्नासाठी आमच्या तज्ञांशी संपर्क साधा.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-10 md:mt-12">
            <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6">
              तुम्हाला हे देखील आवडेल
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
              {relatedProducts.map((relatedProduct) => (
                <Link
                  key={relatedProduct.id}
                  to={`/product/${relatedProduct.id}`}
                  className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-shadow overflow-hidden"
                  onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                >
                  <img
                    src={relatedProduct.image}
                    alt={relatedProduct.nameMarathi}
                    className="w-full aspect-square object-cover"
                  />
                  <div className="p-4">
                    <p className="text-xs text-[#8b7355] mb-1">{relatedProduct.categoryMarathi}</p>
                    <h3 className="text-sm md:text-base font-semibold text-gray-900 mb-2 line-clamp-2">
                      {relatedProduct.nameMarathi}
                    </h3>
                    <p className="text-base md:text-lg font-bold text-[#2d7a3e]">₹{relatedProduct.price}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Sticky Bottom Bar - Mobile */}
      {showStickyBar && (
        <div className="fixed bottom-0 left-0 right-0 bg-white shadow-2xl border-t z-50 lg:hidden">
          <div className="container mx-auto px-4 py-3">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleCallNow}
                className="bg-[#2d7a3e] hover:bg-[#245c30] text-white py-3 rounded-lg transition-colors flex items-center justify-center gap-2 font-semibold text-sm"
              >
                <Phone className="w-4 h-4" />
                <span>कॉल करा</span>
              </button>
              
              <button
                onClick={handleWhatsApp}
                className="bg-[#25D366] hover:bg-[#20BA5A] text-white py-3 rounded-lg transition-colors flex items-center justify-center gap-2 font-semibold text-sm"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}
