import { Phone, MessageCircle, Shield, Heart, Leaf, Award, CheckCircle2, Star } from "lucide-react";
import { ProductCard } from "../components/ProductCard";
import { Footer } from "../components/Footer";
import { products, contactInfo, foundationInfo } from "../data/products";

export function Home() {
  const featuredProducts = products.filter(p => p.featured);
  const allProducts = products;

  const handleCallNow = () => {
    window.location.href = `tel:${contactInfo.phone}`;
  };

  const handleWhatsApp = () => {
    window.open(`https://wa.me/${contactInfo.whatsapp}?text=नमस्कार, मला आयुर्वेदिक उत्पादनांबद्दल माहिती हवी आहे.`, '_blank');
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#e8f5e9] via-white to-[#fef7ed] overflow-hidden">
        <div className="container mx-auto px-4 py-12 md:py-20 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-6 md:space-y-8 text-center lg:text-left">
              <div className="inline-block bg-[#2d7a3e]/10 text-[#2d7a3e] px-4 py-2 rounded-full text-sm font-medium">
                100% नैसर्गिक आयुर्वेदिक उत्पादने
              </div>
              
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                <span className="text-[#2d7a3e]">निसर्गाचे ज्ञान,</span>
                <br />
                आधुनिक आरोग्यासाठी
              </h1>
              
              <p className="text-base md:text-lg lg:text-xl text-gray-600 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                {foundationInfo.taglineMarathi}
              </p>

              <p className="text-sm md:text-base text-gray-600 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                पारंपरिक आयुर्वेदिक सूत्रांनी तयार केलेली 100% नैसर्गिक उत्पादने. 
                कोणतेही साइड इफेक्ट नाहीत. आरोग्यासाठी सुरक्षित आणि प्रमाणित.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start pt-4">
                <button
                  onClick={handleCallNow}
                  className="group bg-[#2d7a3e] hover:bg-[#245c30] text-white px-6 md:px-8 py-3 md:py-4 rounded-xl transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 text-base md:text-lg font-semibold"
                >
                  <Phone className="w-5 h-5 group-hover:animate-pulse" />
                  <span>आता कॉल करा</span>
                </button>
                
                <button
                  onClick={handleWhatsApp}
                  className="group bg-[#25D366] hover:bg-[#20BA5A] text-white px-6 md:px-8 py-3 md:py-4 rounded-xl transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2 text-base md:text-lg font-semibold"
                >
                  <MessageCircle className="w-5 h-5 group-hover:animate-pulse" />
                  <span>WhatsApp वर संपर्क</span>
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 md:gap-6 pt-4 text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <CheckCircle2 className="w-5 h-5 text-[#2d7a3e]" />
                  <span>100% नैसर्गिक</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <CheckCircle2 className="w-5 h-5 text-[#2d7a3e]" />
                  <span>प्रमाणित उत्पादने</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <CheckCircle2 className="w-5 h-5 text-[#2d7a3e]" />
                  <span>साइड इफेक्ट नाहीत</span>
                </div>
              </div>
            </div>

            {/* Right Image */}
            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1705083649602-03c5fbae2e89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxheXVydmVkaWMlMjBoZXJicyUyMG5hdHVyYWwlMjB3ZWxsbmVzc3xlbnwxfHx8fDE3NzUyMDgyMTh8MA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Ayurvedic Products"
                  className="w-full h-[300px] sm:h-[400px] lg:h-[500px] object-cover"
                />
                {/* Overlay Badge */}
                <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-sm p-4 rounded-xl shadow-lg">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center text-yellow-500">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">5000+ समाधानी ग्राहक</p>
                      <p className="text-sm text-gray-600">विश्वासार्ह आयुर्वेदिक उत्पादने</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Floating Elements */}
              <div className="hidden lg:block absolute -top-6 -right-6 bg-white p-4 rounded-full shadow-xl">
                <Leaf className="w-8 h-8 text-[#2d7a3e]" />
              </div>
              <div className="hidden lg:block absolute -bottom-6 -left-6 bg-white p-4 rounded-full shadow-xl">
                <Heart className="w-8 h-8 text-[#d4183d]" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-12 md:py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            <div className="bg-gradient-to-br from-[#e8f5e9] to-white p-6 rounded-xl text-center shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 md:w-16 md:h-16 bg-[#2d7a3e] rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Leaf className="w-7 h-7 md:w-8 md:h-8 text-white" />
              </div>
              <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">
                100% नैसर्गिक
              </h3>
              <p className="text-xs md:text-sm text-gray-600">
                शुद्ध औषधी वनस्पतींपासून तयार
              </p>
            </div>

            <div className="bg-gradient-to-br from-[#fef7ed] to-white p-6 rounded-xl text-center shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 md:w-16 md:h-16 bg-[#8b7355] rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Shield className="w-7 h-7 md:w-8 md:h-8 text-white" />
              </div>
              <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">
                साइड इफेक्ट नाहीत
              </h3>
              <p className="text-xs md:text-sm text-gray-600">
                सुरक्षित आणि प्रभावी
              </p>
            </div>

            <div className="bg-gradient-to-br from-[#e8f5e9] to-white p-6 rounded-xl text-center shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 md:w-16 md:h-16 bg-[#2d7a3e] rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Heart className="w-7 h-7 md:w-8 md:h-8 text-white" />
              </div>
              <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">
                विश्वासार्ह
              </h3>
              <p className="text-xs md:text-sm text-gray-600">
                5000+ समाधानी ग्राहक
              </p>
            </div>

            <div className="bg-gradient-to-br from-[#fef7ed] to-white p-6 rounded-xl text-center shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 md:w-16 md:h-16 bg-[#8b7355] rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Award className="w-7 h-7 md:w-8 md:h-8 text-white" />
              </div>
              <h3 className="text-base md:text-lg font-semibold text-gray-900 mb-2">
                प्रमाणित
              </h3>
              <p className="text-xs md:text-sm text-gray-600">
                गुणवत्ता आश्वासित
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-12 md:py-16 bg-gradient-to-b from-gray-50 to-white scroll-mt-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10 md:mb-12">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-3 md:mb-4">
              आमची उत्पादने
            </h2>
            <p className="text-sm md:text-base text-gray-600 max-w-2xl mx-auto px-4">
              पारंपरिक आयुर्वेदिक सूत्रांनी तयार केलेली प्रीमियम उत्पादने
            </p>
          </div>

          {/* Product Grid - Responsive */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {allProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-12 md:py-16 bg-white scroll-mt-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-4">
                आमच्याबद्दल
              </h2>
              <p className="text-lg md:text-xl text-[#2d7a3e] font-semibold">
                {foundationInfo.nameMarathi}
              </p>
            </div>

            <div className="bg-gradient-to-br from-[#e8f5e9] to-white p-6 md:p-10 rounded-2xl shadow-lg">
              <p className="text-base md:text-lg text-gray-700 leading-relaxed mb-6">
                {foundationInfo.descriptionMarathi}
              </p>

              <div className="grid sm:grid-cols-2 gap-4 mt-8">
                <div className="flex items-start gap-3 p-4 bg-white rounded-lg">
                  <CheckCircle2 className="w-6 h-6 text-[#2d7a3e] flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">पारंपरिक फॉर्म्युला</h4>
                    <p className="text-sm text-gray-600">प्राचीन आयुर्वेदिक ज्ञानावर आधारित</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-4 bg-white rounded-lg">
                  <CheckCircle2 className="w-6 h-6 text-[#2d7a3e] flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">सामाजिक प्रतिष्ठान</h4>
                    <p className="text-sm text-gray-600">समाजसेवेसाठी समर्पित</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-4 bg-white rounded-lg">
                  <CheckCircle2 className="w-6 h-6 text-[#2d7a3e] flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">गुणवत्ता आश्वासन</h4>
                    <p className="text-sm text-gray-600">प्रत्येक उत्पादन चाचणी केलेले</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-4 bg-white rounded-lg">
                  <CheckCircle2 className="w-6 h-6 text-[#2d7a3e] flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">परवडणारे दर</h4>
                    <p className="text-sm text-gray-600">सर्वांसाठी आरोग्य सेवा</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-16 bg-gradient-to-br from-[#2d7a3e] to-[#245c30] text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 md:mb-6">
            आजच सुरू करा आपला आरोग्य प्रवास
          </h2>
          <p className="text-base md:text-lg mb-6 md:mb-8 opacity-95 max-w-2xl mx-auto">
            निसर्गाच्या शक्तीने आपले आरोग्य सुधारवा. आजच ऑर्डर करा किंवा आमच्याशी संपर्क साधा.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={handleCallNow}
              className="group bg-white text-[#2d7a3e] hover:bg-gray-100 px-6 md:px-8 py-3 md:py-4 rounded-xl transition-all shadow-lg hover:shadow-xl flex items-center gap-2 text-base md:text-lg font-semibold w-full sm:w-auto justify-center"
            >
              <Phone className="w-5 h-5 group-hover:animate-pulse" />
              <span>आता कॉल करा</span>
            </button>
            
            <button
              onClick={handleWhatsApp}
              className="group bg-[#25D366] hover:bg-[#20BA5A] text-white px-6 md:px-8 py-3 md:py-4 rounded-xl transition-all shadow-lg hover:shadow-xl flex items-center gap-2 text-base md:text-lg font-semibold w-full sm:w-auto justify-center"
            >
              <MessageCircle className="w-5 h-5 group-hover:animate-pulse" />
              <span>WhatsApp करा</span>
            </button>
          </div>

          <p className="text-sm mt-6 opacity-90">
            {contactInfo.phone} | सोमवार ते शनिवार, सकाळी 9 ते संध्याकाळी 7
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-12 md:py-16 bg-gray-50 scroll-mt-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              आमच्याशी संपर्क साधा
            </h2>
            <p className="text-sm md:text-base text-gray-600">
              आम्हाला तुम्हाला मदत करण्यात आनंद होईल
            </p>
          </div>

          <div className="max-w-3xl mx-auto grid md:grid-cols-3 gap-6">
            <a
              href={`tel:${contactInfo.phone}`}
              className="flex flex-col items-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow"
            >
              <Phone className="w-10 h-10 text-[#2d7a3e] mb-3" />
              <h3 className="font-semibold text-gray-900 mb-1">फोन</h3>
              <p className="text-sm text-gray-600 text-center">{contactInfo.phone}</p>
            </a>

            <button
              onClick={handleWhatsApp}
              className="flex flex-col items-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow"
            >
              <MessageCircle className="w-10 h-10 text-[#25D366] mb-3" />
              <h3 className="font-semibold text-gray-900 mb-1">WhatsApp</h3>
              <p className="text-sm text-gray-600 text-center">त्वरित प्रतिसाद</p>
            </button>

            <a
              href={`mailto:${contactInfo.email}`}
              className="flex flex-col items-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow"
            >
              <Mail className="w-10 h-10 text-[#2d7a3e] mb-3" />
              <h3 className="font-semibold text-gray-900 mb-1">ईमेल</h3>
              <p className="text-xs text-gray-600 text-center break-all px-2">{contactInfo.email}</p>
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
