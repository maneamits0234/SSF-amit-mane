import { Outlet } from "react-router";
import { Header } from "./components/Header";
import { Cart, CartItem } from "./components/Cart";

interface LayoutProps {
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: number, quantity: number) => void;
  onRemoveItem: (productId: number) => void;
}

export function Layout({ 
  cartOpen, 
  setCartOpen, 
  cartItems, 
  onUpdateQuantity, 
  onRemoveItem 
}: LayoutProps) {
  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-white">
      <Header cartItemCount={totalItems} onCartClick={() => setCartOpen(true)} />
      <Outlet />
      <Cart
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={onUpdateQuantity}
        onRemoveItem={onRemoveItem}
      />
    </div>
  );
}
