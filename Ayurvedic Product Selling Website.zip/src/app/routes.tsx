import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { ProductDetail } from "./pages/ProductDetail";
import { Layout } from "./Layout";
import { CartItem } from "./components/Cart";

interface RouteContext {
  onAddToCart: (productId: number) => void;
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: number, quantity: number) => void;
  onRemoveItem: (productId: number) => void;
}

export const createRouter = (context: RouteContext) => 
  createBrowserRouter([
    {
      path: "/",
      element: <Layout 
        cartOpen={context.cartOpen}
        setCartOpen={context.setCartOpen}
        cartItems={context.cartItems}
        onUpdateQuantity={context.onUpdateQuantity}
        onRemoveItem={context.onRemoveItem}
      />,
      children: [
        {
          index: true,
          Component: Home,
        },
        {
          path: "product/:id",
          element: <ProductDetail onAddToCart={context.onAddToCart} />,
        },
      ],
    },
  ]);